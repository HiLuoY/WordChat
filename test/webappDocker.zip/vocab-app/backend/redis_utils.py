### redis_utils.py
import redis
import json
import os

# 从环境变量获取 Redis 配置
REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
REDIS_DB = int(os.getenv('REDIS_DB', 0))

# 创建 Redis 连接
r = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    db=REDIS_DB,
    decode_responses=True
)

def set_room_state(room_id, state: dict, expire=3600):
    """设置房间状态，默认1小时后过期"""
    r.setex(f"room_state:{room_id}", expire, json.dumps(state))

def get_room_state(room_id):
    val = r.get(f"room_state:{room_id}")
    return json.loads(val) if val else None

def del_room_state(room_id):
    r.delete(f"room_state:{room_id}")
